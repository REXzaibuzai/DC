'use strict';

const mgu=require('./kit/mgu');
const G=require('./kit/gauges');
const fs=require('fs');
const os=require('os');
const sharemod=require('./share.js');
const W=1600,H=520,PAGES=['服务目录','报告','手机下载','说明','线索','结构'];
const GREEN='#32e875',AMBER='#ffb52e',CYAN='#35d6d0',BLUE='#4aafff',RED='#ff3658';
const PATHS=[
    '/etc/oap/someip/someip-interfaces.json',
    '/var/oap/someip/someip-interfaces.json',
    '/etc/oap/someip-interfaces.json',
    '/opt/oap/someip/someip-interfaces.json',
    '/usr/share/oap/someip/someip-interfaces.json'
];
const FILTERS=[
    {key:'env',  label:'环境模型', test:(n)=>/environmentalmodel/i.test(n)},
    {key:'lane', label:'车道',     test:(n)=>/lane/i.test(n)},
    {key:'obj',  label:'目标物',   test:(n)=>/object|target|vehicleobject/i.test(n)},
    {key:'cam',  label:'摄像头',   test:(n)=>/frontcamera|camera/i.test(n)},
    {key:'all',  label:'全部',     test:()=>true}
];
const REPORT_NAME='env_probe_scan.txt';

function collect(node,out,seen){
    if(!node||typeof node!=='object')return;
    if(Array.isArray(node)){node.forEach((n)=>collect(n,out,seen));return;}
    const name=node.name||node.serviceName||node.interfaceName||node.service;
    if(typeof name==='string'&&/^de\.bmw\./i.test(name)&&!seen.has(name)){
        seen.add(name);
        const fields=[];
        for(const k of ['fields','events','methods','broadcasts','services','signals','args','vars','properties']){
            const arr=node[k];
            if(Array.isArray(arr))arr.forEach((it)=>{
                const n=typeof it==='string'?it:(it&&(it.name||it.fieldName||it.id||it.methodName));
                if(n)fields.push(String(n));
            });
            else if(arr&&typeof arr==='object')Object.keys(arr).forEach((k2)=>fields.push(k2));
        }
        out.push({name,fields});
    }
    Object.keys(node).forEach((k)=>{
        if(/^de\.bmw\./i.test(k)&&!seen.has(k)){
            seen.add(k);
            const v=node[k],f2=[];
            if(Array.isArray(v))v.forEach((it)=>{
                const n=typeof it==='string'?it:(it&&(it.name||it.fieldName||it.id||it.methodName));
                if(n)f2.push(String(n));
            });
            else if(v&&typeof v==='object')Object.keys(v).forEach((k2)=>f2.push(k2));
            out.push({name:k,fields:f2});
        }
        collect(node[k],out,seen);
    });
}

function load(){
    const errors=[];
    for(const p of PATHS){
        try{
            const text=fs.readFileSync(p,'utf8');
            if(!text||text.length<200){errors.push(p+': 文件太小');continue;}
            let json=null;
            try{json=JSON.parse(text);}catch(e){errors.push(p+': 不是合法 JSON ('+e.message+')');continue;}
            const services=[];collect(json,services,new Set());
            return {ok:true,path:p,bytes:text.length,raw:text,json,services,errors};
        }catch(e){errors.push(p+': '+e.message);}
    }
    return {ok:false,path:null,bytes:0,raw:'',json:null,services:[],errors};
}

function buildReport(data){
    const lines=[];
    lines.push('# env_probe scan');
    lines.push('time: '+new Date().toISOString());
    lines.push('path: '+(data.path||'(none)'));
    lines.push('bytes: '+data.bytes);
    lines.push('services: '+data.services.length);
    lines.push('');
    lines.push('## read attempts');
    (data.errors.length?data.errors:['(none)']).forEach((e)=>lines.push('- '+e));
    lines.push('');
    if(!data.ok){
        lines.push('## verdict');
        lines.push('no SOME/IP catalog file was readable by the app process.');
        if(data.raw&&data.raw.length)lines.push('', '## raw head', data.raw.slice(0,4000));
        return lines.join('\n');
    }
    lines.push('## summary by keyword');
    for(const f of FILTERS){
        const n=data.services.filter((s)=>f.test(s.name)).length;
        lines.push('- '+f.key+' ('+f.label+'): '+n);
    }
    lines.push('');
    lines.push('## environment model / lane / object / camera services');
    const hit=data.services.filter((s)=>FILTERS[0].test(s.name)||FILTERS[1].test(s.name)||FILTERS[2].test(s.name)||FILTERS[3].test(s.name));
    hit.forEach((s)=>{
        lines.push('');
        lines.push('### '+s.name);
        lines.push('fields('+s.fields.length+'): '+s.fields.join(', '));
    });
    lines.push('');
    lines.push('## all services (name + field count)');
    data.services.forEach((s)=>lines.push(s.name+'  ['+s.fields.length+']  '+s.fields.join(', ')));
    return lines.join('\n');
}

function writeReport(text){
    const dirs=[];
    try{fs.readdirSync('/media').forEach((d)=>{try{if(fs.statSync('/media/'+d).isDirectory())dirs.push('/media/'+d);}catch(e){}});}catch(e){}
    try{if(fs.statSync('/media').isDirectory())dirs.push('/media');}catch(e){}
    dirs.push('/tmp');
    const written=[],errors=[];
    for(const d of dirs){
        const p=d+'/'+REPORT_NAME;
        try{
            fs.writeFileSync(p,text,'utf8');
            const st=fs.statSync(p);
            if(st.size>0)written.push({path:p,size:st.size});
            else errors.push(p+': 写出来是空文件');
        }catch(e){errors.push(p+': '+e.message);}
    }
    return {written,errors};
}

const DEF_IFACES=[
    'de.bmw.environmentalmodel.Lanes',
    'de.bmw.environmentalmodel.LaneBoundaries',
    'de.bmw.environmentalmodel.ObjectRecognitionFrontCamera2',
    'de.bmw.environmentalmodel.TrafficLightRecognitionFrontCameraLegacy'
];
let defsDone=false,defsInfo=null;
function buildDefs(jsonIn){
    if(!jsonIn)return {ok:false,why:'接口定义文件没读到'};
    const out=['','## defs','time: '+new Date().toISOString()],info=[];
    DEF_IFACES.forEach((n)=>{
        const node=jsonIn[n];
        if(!node){out.push('','### '+n,'(missing)');info.push({name:n,bytes:0,miss:true});return;}
        const s=JSON.stringify(node,null,1);
        const cut=s.length>120000?s.slice(0,120000)+'\n...(cut)':s;
        out.push('','### '+n,'bytes: '+s.length,cut);
        info.push({name:n,bytes:s.length});
    });
    return {ok:true,text:out.join('\n'),info};
}
function clueLines(list){
    const groups=[{re:/trafficlight/i,p:0},{re:/lane/i,p:1},{re:/object|vehicle/i,p:2},
                  {re:/camera/i,p:3},{re:/environmentalmodel/i,p:4}];
    const seen=new Set(),out=[];
    groups.forEach((g)=>list.forEach((s)=>{
        if(seen.has(s.name)||!g.re.test(s.name))return;
        seen.add(s.name);out.push({p:g.p,name:s.name,fields:s.fields.length});
    }));
    out.sort((a,b)=>a.p-b.p||a.name.localeCompare(b.name));
    return out.slice(0,18);
}
function chunksOf(lines,maxBytes){
    const out=[];let cur='';
    lines.forEach((l)=>{
        if(Buffer.byteLength(cur+l+'\n')>maxBytes){out.push(cur);cur='';}
        cur+=l+'\n';
    });
    if(cur)out.push(cur);
    return out;
}

mgu.run({async start(ctx){
    const {ui}=ctx;
    const data=load();
    let report=buildReport(data);
    const saved=writeReport(report);
    const meta={time:new Date().toLocaleString('zh-CN'),path:data.path,count:data.services.length,bytes:Buffer.byteLength(report)};
    let share=sharemod.startShare(()=>report,meta);
    let filter=0,offset=0,state={page:0,chunk:0};
    const clue=clueLines(data.services);
    const CLUE=chunksOf(clue.map((c)=>c.name+' ['+c.fields+']'),460);

    function rowsFor(){
        const f=FILTERS[filter];
        return {f,list:data.services.filter((s)=>f.test(s.name))};
    }
    function page0(cv,t){
        const {f,list}=rowsFor();
        G.panel(cv,t,24,54,1552,458,'车机 SOME/IP 服务目录(只读)');
        if(!data.ok){
            cv.text('读取失败',54,110,38,RED,{font:'bold'});
            data.errors.slice(0,4).forEach((e,i)=>cv.text(String(e).slice(0,120),54,164+i*30,19,t.dim));
            cv.text('看“报告”页:那里写了尝试过的路径和错误。',54,320,21,t.text);
            cv.text('报告文件: '+(saved.written.length?saved.written[0].path:'没能写出去'),54,360,19,CYAN);
            return;
        }
        cv.text(data.path,54,104,19,t.dim);
        cv.text('共 '+data.services.length+' 个服务 · “'+f.label+'” '+list.length+' 个 · '+Math.round(data.bytes/1024)+' KB',54,134,22,t.text);
        const rows=list.slice(offset,offset+6).map((s)=>[s.name,s.fields.length?s.fields.length+' 项':'—',s.fields.slice(0,6).join(', ')||'—']);
        G.table(cv,t,48,168,1504,[{label:'服务名',w:640},{label:'字段',w:120},{label:'部分字段名',w:744}],rows,{rowH:52,size:18,empty:'这一筛选项下没有匹配的服务。'});
        const pages=Math.max(1,Math.ceil(list.length/6)),cur=Math.min(pages,Math.floor(offset/6)+1);
        cv.text('第 '+cur+' 页 / 共 '+pages+' 页',48,492,18,t.dim);
    }
    function page1(cv,t){
        G.panel(cv,t,24,54,760,458,'报告文件');
        if(saved.written.length){
            cv.text('已写出 '+saved.written.length+' 份',54,110,26,GREEN,{font:'bold'});
            saved.written.slice(0,4).forEach((w,i)=>{
                cv.text(w.path.slice(0,58),54,160+i*32,19,t.text);
                cv.text((w.size/1024).toFixed(1)+' KB',54,186+i*32,17,t.dim);
            });
            cv.text('把这份 txt 拷出来发我就行。',54,404,21,CYAN);
        }else{
            cv.text('没能写出报告',54,110,26,RED,{font:'bold'});
            saved.errors.slice(0,5).forEach((e,i)=>cv.text(String(e).slice(0,110),54,158+i*30,18,t.dim));
            cv.text('退回“说明”页用 SSH 取。',54,400,21,AMBER);
        }
        G.panel(cv,t,804,54,772,458,'报告里有什么');
        cv.text('· 实际读到的文件路径与大小',828,110,20,t.text);
        cv.text('· 所有尝试过的路径和错误',828,150,20,t.text);
        cv.text('· 服务总数,按关键词的分布',828,190,20,t.text);
        cv.text('· 环境模型/车道/目标物/摄像头',828,230,20,t.text);
        cv.text('  每个服务的完整字段列表',828,262,20,t.text);
        cv.text('· 全部服务及字段(便于我做适配)',828,302,20,t.text);
        cv.text('文件是纯文本,可直接发我。',828,400,20,CYAN);
    }
    function page3(cv,t){
        G.panel(cv,t,24,54,760,458,'这个程序做什么');
        cv.text('只读,不写任何车机设置。',54,110,24,GREEN,{font:'bold'});
        cv.text('它找车机的 SOME/IP 主目录文件,',54,158,20,t.text);
        cv.text('把 de.bmw.* 的服务名和字段名读出来,',54,190,20,t.text);
        cv.text('写成一份 txt 报告放到 U 盘。',54,222,20,t.text);
        cv.text('不订阅、不激活、不改编码。',54,300,20,CYAN);
        cv.text('这样就不用在屏幕上看,直接发文件给我。',54,400,20,t.text);
        G.panel(cv,t,804,54,772,458,'报告没写出来时用 SSH');
        cv.text('find / -name someip-interfaces.json',828,110,20,t.text,{literal:true,font:'num'});
        cv.text('cat <上面找到的文件> | head -c 200000 >',828,152,19,t.text,{literal:true,font:'num'});
        cv.text('/tmp/someip.json',828,182,19,t.text,{literal:true,font:'num'});
        cv.text('然后 scp 出来发我。',828,230,20,t.text);
    }
    function page2(cv,t){
        G.panel(cv,t,24,54,600,458,'手机扫码下载报告');
        if(share.url){
            sharemod.drawQr(cv,share.url,78,96,306,4);
            cv.text(share.url,78,428,15,CYAN,{literal:true,font:'num'});
            cv.text('关掉本程序,链接即失效',78,462,15,t.dim);
        }else{
            cv.text('下载服务没起来',78,140,28,RED,{font:'bold'});
            cv.text('原因见右边。',78,196,20,t.text);
            cv.text('按“下一页”可重试一次。',78,236,18,t.dim);
        }
        G.panel(cv,t,644,54,932,458,'手机上四步');
        cv.text('① 手机连车机 Wi-Fi(或车机连手机热点)',668,94,19,t.text);
        cv.text('② 相机扫左边的码,或浏览器输地址',668,126,19,t.text);
        cv.text('③ 点绿色“下载 txt”',668,158,19,t.text);
        cv.text('④ 文件落在手机“文件”里,发我就行',668,190,19,t.text);
        cv.text('状态 '+share.status+' · 防火墙 '+share.fw.state,668,232,20,share.url?GREEN:RED,{font:'bold'});
        if(share.ip)cv.text('车机 '+share.ip+' · 端口 '+share.port,668,262,17,t.dim);
        if(share.fw.msg)cv.text('防火墙:'+share.fw.msg,668,288,16,AMBER);
        const alt=share.alt;
        if(alt){
            const d=alt.dir,u=alt.usb;
            const okd=d&&d.state==='已放入';
            cv.text('备用① 日志目录 '+(d?d.state:'-'),668,320,17,okd?GREEN:AMBER);
            if(okd){
                cv.text('打开 CarPlay 仪表地图的日志页,点这条下载:',668,344,16,CYAN);
                cv.text(d.name,668,366,15,CYAN,{literal:true,font:'num'});
            }
            const oku=u&&u.state==='已写入U盘';
            cv.text('备用② U盘 '+(u?u.state:'-'),668,396,17,oku?GREEN:AMBER);
            if(oku)cv.text(u.name.slice(0,40),668,418,14,CYAN,{literal:true,font:'num'});
        }
    }
    function page4(cv,t){
        const n=Math.max(1,CLUE.length),idx=Math.min(state.chunk||0,n-1);
        G.panel(cv,t,24,54,600,458,'扫码带走这一片');
        if(CLUE.length){
            sharemod.drawQr(cv,CLUE[idx],132,72,420,4);
            cv.text('片 '+(idx+1)+' / '+n,132,506,18,CYAN);
        }else{
            cv.text('没有命中项',78,240,28,RED,{font:'bold'});
        }
        G.panel(cv,t,644,54,932,458,'关键线索');
        const ls=(CLUE[idx]||'').split('\n').slice(0,7);
        ls.forEach((l,i)=>cv.text(l.slice(0,60),668,104+i*32,17,t.text,{literal:true,font:'num'}));
        cv.text('相关服务 '+clue.length+' 条 · 按相关度排序',668,384,17,CYAN);
        cv.text('手机扫码,把解出来的文本发我',668,414,17,t.text);
        cv.text('或直接拍这一页',668,442,17,t.dim);
    }
    function ensureDefs(){
        if(defsDone)return;
        defsDone=true;
        const r=buildDefs(data.json);
        defsInfo=r;
        if(!r.ok)return;
        const cut=report.indexOf('\n\n## defs');
        report=(cut>=0?report.slice(0,cut):report)+r.text;
        try{state.defSaved=writeReport(report).written.length>0;}catch(e){state.defSaved=false;}
    }
    function page5(cv,t){
        G.panel(cv,t,24,54,1552,458,'车道与目标物:把接口定义导出来');
        if(!defsInfo||!defsInfo.ok){
            cv.text(defsInfo?defsInfo.why:'还没导出',60,250,26,RED,{font:'bold'});
            return;
        }
        defsInfo.info.forEach((d,i)=>{
            cv.text((d.miss?'缺  ':'有  ')+d.name,56,86+i*46,17,d.miss?AMBER:CYAN,{literal:true,font:'num'});
            cv.text(d.miss?'定义文件里没有这条':(d.bytes+' 字节'),620,86+i*46,16,t.dim,{literal:true,font:'num'});
        });
        cv.text('已写进报告: '+(state.defSaved?'是,手机上能一起下走':'没写进,先看屏幕'),56,300,18,state.defSaved?GREEN:AMBER);
        cv.text('这两段定义里就有车道数组长度,拿到就能画线',56,338,18,t.text);
        cv.text('BTN_ACTION 重新导一次',56,376,16,t.dim);
    }
    async function render(){
        const t=ctx.theme(),cv=ctx.canvas(W,H).clear(t.bg);
        if(state.page===5)page5(cv,t);else if(state.page===4)page4(cv,t);else if(state.page===3)page3(cv,t);else if(state.page===2)page2(cv,t);else if(state.page===1)page1(cv,t);else page0(cv,t);
        G.frame(cv,t,PAGES,state.page,[{text:data.ok?'只读':'读取失败',color:data.ok?GREEN:RED},{text:FILTERS[filter].label,color:CYAN}]);
        await ui.image('MAIN_GFX',cv);
    }
    ui.onClick('BTN_PAGE',()=>{state.page=(state.page+1)%PAGES.length;if(state.page===5)ensureDefs();});
    ui.onClick('BTN_ACTION',()=>{
        if(state.page===5){defsDone=false;ensureDefs();return;}
        if(state.page===4){
            state.chunk=((state.chunk||0)+1)%Math.max(1,CLUE.length);
            return;
        }
        if(state.page===2){
            sharemod.stopShare(share);
            share=sharemod.startShare(()=>report,meta);
            return;
        }
        const {list}=rowsFor();
        if(state.page===0&&offset+6<list.length)offset+=6;
        else{offset=0;filter=(filter+1)%FILTERS.length;state.page=0;}
    });
    ctx.onTab((i)=>{state.page=Math.max(0,Math.min(PAGES.length-1,i));});
    ctx.loop('MAIN',30,render);
}});
