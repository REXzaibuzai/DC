'use strict';
/**
 * The phone page: the report is served over HTTP, the screen shows a QR code
 * pointing at it. Mirrors what the update planner's "Phone access" does on
 * this head unit - listens on a fixed port, opens one tagged rule at the top
 * of nft's ip filter input chain (the unit's firewall drops the rest), and
 * re-checks that rule every 30 s because a ruleset load at boot removes it.
 */
const os = require('os');
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const http = require('http');
const cp = require('child_process');
const qrcodegen = require('./qrcodegen.js');

const PORT_PREF = 8471;
const NFT_COMMENT = 'env_probe web';

/* ---------- firewall ---------- */
let nftQueue = Promise.resolve();

const BIN_DIRS = ['/usr/sbin', '/sbin', '/usr/bin', '/bin', '/usr/local/sbin', '/opt/bin'];
const binPath = {};
/* the app's PATH on this head unit does not always contain /usr/sbin, so nft and
 * iptables are looked up by absolute path before falling back to PATH */
function findBin(name) {
    if (binPath[name] !== undefined) return binPath[name];
    for (let i = 0; i < BIN_DIRS.length; i += 1) {
        const p = BIN_DIRS[i] + '/' + name;
        try { if (fs.existsSync(p)) { binPath[name] = p; return p; } } catch (e) { /* keep looking */ }
    }
    binPath[name] = name;
    return name;
}

function exec(bin, args) {
    return new Promise((resolve, reject) => {
        cp.execFile(findBin(bin), args, {
            timeout: 15000, maxBuffer: 4 << 20,
            env: Object.assign({}, process.env,
                { PATH: (process.env.PATH || '/usr/bin:/bin') + ':/usr/sbin:/sbin:/usr/local/sbin' })
        }, (err, stdout, stderr) => {
            if (!err) { resolve(String(stdout || '')); return; }
            const msg = String((stderr || err.message || err.code || '')).trim() || '命令失败';
            const e2 = new Error(msg);
            e2.code = err.code;
            reject(e2);
        });
    });
}

function nft(args) { return exec('nft', args); }

function ruleHandles() {
    return nft(['-a', 'list', 'chain', 'ip', 'filter', 'input']).then(
        (out) => ({ handles: out.split('\n')
            .filter((line) => line.indexOf(`comment "${NFT_COMMENT}"`) >= 0)
            .map((line) => /# handle (\d+)\s*$/.exec(line))
            .filter(Boolean)
            .map((m) => m[1]) }),
        (e) => {
            const msg = String((e && (e.message || e.code)) || e);
            if (/ENOENT/i.test(msg) || (e && e.code === 'ENOENT')) return { handles: null, missing: true, noBin: true, msg };
            if (/no such|does not exist|cannot find/i.test(msg)) return { handles: null, missing: true, msg };
            if (/operation not permitted|permission|EPERM|EACCES/i.test(msg)) return { handles: null, denied: true, msg };
            return { handles: null, msg };
        });
}

/* last resort: this head unit may police the input chain with iptables instead */
function iptablesRule(port) {
    const base = ['-p', 'tcp', '--dport', String(port), '-j', 'ACCEPT'];
    return exec('iptables', ['-C', 'INPUT'].concat(base))
        .then(() => ({ state: '已放行', msg: 'iptables 已有规则' }))
        .catch(() => exec('iptables', ['-I', 'INPUT'].concat(base))
            .then(() => ({ state: '已放行', msg: 'iptables' }))
            .catch((e) => ({ state: '放行失败', msg: String((e && e.message) || e).slice(0, 88) })));
}

function ensureRule(iface, port) {
    return ruleHandles().then((r) => {
        if (r.denied) return { state: '放行失败', msg: '这个程序没有 root 权限执行 nft' };
        if (r.msg && !r.missing) return { state: '放行失败', msg: String(r.msg).slice(0, 88) };
        if (r.handles && r.handles.length) return { state: '已放行', msg: '' };
        if (r.missing) return iptablesRule(port);
        return nft(['insert', 'rule', 'ip', 'filter', 'input', 'iifname', `"${iface}"`,
            'tcp', 'dport', String(port), 'accept', 'comment', `"${NFT_COMMENT}"`])
            .then(() => ({ state: '已放行', msg: '' }))
            .catch((e) => iptablesRule(port).then((r2) => (r2.state === '已放行' ? r2
                : { state: '放行失败', msg: String((e && e.message) || e).slice(0, 88) })));
    });
}

function queued(fn) {
    nftQueue = nftQueue.then(fn, fn);
    return nftQueue;
}

/* ---------- fallbacks: no firewall rule, no root ---------- */
/* The CarPlay cluster-maps app ships a root service that serves /var/opt/
 * waze-on-cluster/saved to a phone at 8475 with the firewall rule already
 * open. Dropping a woc-logs-<UTC>.tar.gz in there makes our report appear in
 * that page, downloadable from the phone - no port of ours, no root. */
const WOC_DIR = '/var/opt/waze-on-cluster/saved';
const WOC_NAME = /^woc-logs-\d{8}T\d{6}Z\.tar\.gz$/;

function zpad(s, n) { return String(s).padStart(n, '0'); }

function utcStamp() {
    const d = new Date();
    return zpad(d.getUTCFullYear(), 4) + zpad(d.getUTCMonth() + 1, 2) + zpad(d.getUTCDate(), 2)
        + 'T' + zpad(d.getUTCHours(), 2) + zpad(d.getUTCMinutes(), 2) + zpad(d.getUTCSeconds(), 2) + 'Z';
}

/* one-file ustar */
function tarGz(name, body) {
    const data = Buffer.from(body, 'utf8');
    const h = Buffer.alloc(512, 0);
    h.write(name.slice(0, 99), 0, 'ascii');
    h.write('0000644\0', 100, 'ascii');
    h.write('0000000\0', 108, 'ascii');
    h.write('0000000\0', 116, 'ascii');
    h.write(zpad(data.length.toString(8), 11) + '\0', 124, 'ascii');
    h.write(zpad(Math.floor(Date.now() / 1000).toString(8), 11) + '\0', 136, 'ascii');
    h.write('        ', 148, 'ascii');
    h.write('0', 156, 'ascii');
    h.write('ustar\0', 257, 'ascii');
    h.write('00', 263, 'ascii');
    h.write('0000000\0', 329, 'ascii');
    h.write('0000000\0', 337, 'ascii');
    let sum = 0;
    for (let i = 0; i < 512; i += 1) sum += h[i];
    h.write(zpad(sum.toString(8), 6) + '\0 ', 148, 'ascii');
    const rest = (512 - (data.length % 512)) % 512;
    const tar = Buffer.concat([h, data, Buffer.alloc(rest, 0), Buffer.alloc(1024, 0)]);
    return zlib.gzipSync(tar);
}

function tryArchiveDir(text) {
    try {
        const st = fs.statSync(WOC_DIR);
        if (!st.isDirectory()) return { state: '不是目录' };
        fs.accessSync(WOC_DIR, fs.constants.W_OK);
        let name = 'woc-logs-' + utcStamp() + '.tar.gz';
        if (!WOC_NAME.test(name)) return { state: '名字不符' };
        fs.writeFileSync(path.join(WOC_DIR, name), tarGz('env_probe_scan.txt', text));
        return { state: '已放入', name };
    } catch (e) {
        const m = String((e && (e.message || e.code)) || e);
        if (/ENOENT/.test(m)) return { state: '车机没有这个目录', msg: '没装 CarPlay 仪表地图的日志功能' };
        if (/EACCES|EPERM/.test(m)) return { state: '没权限写', msg: '目录属于别的程序' };
        return { state: '写入失败', msg: m.slice(0, 60) };
    }
}

function tryUsb(text) {
    const fsOk = /^(vfat|exfat|msdos|ntfs|ntfs3|fuseblk|iso9660)$/;
    try {
        const lines = fs.readFileSync('/proc/mounts', 'utf8').split('\n');
        for (let i = 0; i < lines.length; i += 1) {
            const f = lines[i].split(' ');
            if (f.length < 3 || !fsOk.test(f[2])) continue;
            const mp = f[1].replace(/\\040/g, ' ');
            const dest = path.join(mp, 'env_probe_scan.txt');
            try {
                fs.writeFileSync(dest, text);
                if (fs.statSync(dest).size === Buffer.byteLength(text)) return { state: '已写入U盘', name: dest };
            } catch (e2) { /* try the next mount */ }
        }
    } catch (e) { /* no /proc/mounts */ }
    return { state: '没找到能写的U盘' };
}

function runFallbacks(text) {
    if (!text) return { dir: { state: '没有报告' }, usb: { state: '没有报告' } };
    return { dir: tryArchiveDir(text), usb: tryUsb(text) };
}

/* ---------- addresses ---------- */
function pickIP() {
    const cand = [], all = [];
    const ifs = os.networkInterfaces();
    Object.keys(ifs).forEach((name) => {
        (ifs[name] || []).forEach((a) => {
            if (a && a.family === 'IPv4' && !a.internal) {
                all.push({ name, address: a.address });
                if (/^(192\.168\.|10\.|172\.(1[6-9]|2\d|3[01])\.)/.test(a.address)) cand.push({ name, address: a.address });
            }
        });
    });
    return { pick: cand[0] || all[0] || null, all };
}

/* ---------- the page ---------- */
function htmlPage(share, meta) {
    const size = (meta.bytes / 1024).toFixed(1);
    return '<!doctype html><html lang="zh-CN"><head><meta charset="utf-8">'
        + '<meta name="viewport" content="width=device-width,initial-scale=1">'
        + '<title>环境模型探测 报告</title><style>'
        + '*{box-sizing:border-box}body{margin:0;padding:24px;background:#0f1115;color:#e8eaee;'
        + 'font:16px/1.6 -apple-system,"PingFang SC","Microsoft YaHei",sans-serif}'
        + 'h1{font-size:20px;margin:0 0 4px}.sub{color:#8b93a1;font-size:13px;margin-bottom:20px}'
        + '.card{background:#171a21;border:1px solid #242936;border-radius:12px;padding:16px;margin-bottom:16px}'
        + '.row{display:flex;justify-content:space-between;padding:6px 0;font-size:14px;border-bottom:1px solid #212532}'
        + '.row:last-child{border:0}.k{color:#8b93a1}.v{font-family:ui-monospace,Menlo,monospace;font-size:13px;word-break:break-all;text-align:right;max-width:60%}'
        + '.btns{display:flex;gap:10px;flex-wrap:wrap;margin-top:8px}'
        + 'a.b{flex:1;min-width:140px;text-align:center;padding:12px 14px;border-radius:10px;text-decoration:none;font-weight:600}'
        + '.dl{background:#32e875;color:#08130c}.vw{background:#242936;color:#e8eaee}'
        + '</style></head><body>'
        + '<h1>环境模型探测 · 报告</h1>'
        + '<div class="sub">车机生成的只读扫描报告,点“下载”存到手机再发出去即可。</div>'
        + '<div class="card">'
        + '<div class="row"><span class="k">报告时间</span><span class="v">' + (meta.time || '') + '</span></div>'
        + '<div class="row"><span class="k">来源文件</span><span class="v">' + (meta.path || '未读到') + '</span></div>'
        + '<div class="row"><span class="k">服务总数</span><span class="v">' + meta.count + '</span></div>'
        + '<div class="row"><span class="k">报告大小</span><span class="v">' + size + ' KB</span></div>'
        + '</div>'
        + '<div class="btns"><a class="b dl" href="/t/' + share.token + '/report.txt" download>下载 txt</a>'
        + '<a class="b vw" href="/t/' + share.token + '/view">在网页里看</a></div>'
        + '<div class="sub" style="margin-top:22px">关闭车机上的这个程序,链接就失效。</div>'
        + '</body></html>';
}

/* ---------- server ---------- */
function openServer(handler, pref) {
    return new Promise((resolve) => {
        const attempt = (port, allowRandom) => {
            const s = http.createServer(handler);
            const onErr = (e) => {
                s.removeListener('error', onErr);
                try { s.close(); } catch (e2) { /* not listening */ }
                if (allowRandom) attempt(0, false);
                else resolve({ server: null, port: 0, err: String((e && (e.message || e.code)) || e) });
            };
            s.once('error', onErr);
            s.once('listening', () => {
                s.removeListener('error', onErr);
                const a = s.address();
                resolve({ server: s, port: (a && a.port) || 0, err: '' });
            });
            s.listen(port, '0.0.0.0');
        };
        attempt(pref, true);
    });
}

/* The native env-probe-share service (root, installed as a tool, port 8472)
 * serves the same report with its own firewall rule. When it answers, its
 * address is what the QR code points at: that path needs no privilege from
 * this app at all. */
function probeNative(share) {
    let net;
    try { net = require('net'); } catch (e) { return; }
    let done = false;
    const sock = net.connect(8472, '127.0.0.1');
    const finish = (ok) => {
        if (done) return;
        done = true;
        try { sock.destroy(); } catch (e) { /* gone */ }
        if (!ok) return;
        const host = (pickIP().pick || {}).address || share.ip;
        share.native = true;
        share.url = 'http://' + host + ':8472/';
        share.status = '系统服务已开';
        share.fw = { state: '系统', msg: '' };
    };
    sock.setTimeout(1500, () => finish(false));
    sock.on('connect', () => finish(true));
    sock.on('error', () => finish(false));
}

function startShare(getReport, meta) {
    const share = {
        server: null, port: 0, token: '', ip: '', iface: '', url: '',
        status: '正在开服务', err: [], ipAll: [], fw: { state: '检查中', msg: '' }, timer: null,
        alt: null,
    };
    try { share.alt = runFallbacks(getReport()); } catch (e) { share.alt = null; }
    function handler(req, res) {
        let p = (req.url || '/').split('?')[0];
        if (p.endsWith('/')) p = p.slice(0, -1);
        const auth = '/t/' + share.token;
        try {
            if (p === '' || p === auth) {
                res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
                res.end(htmlPage(share, meta));
            } else if (p === auth + '/report.txt') {
                res.writeHead(200, {
                    'Content-Type': 'text/plain; charset=utf-8',
                    'Content-Disposition': 'attachment; filename="env_probe_scan.txt"', 'Cache-Control': 'no-store',
                });
                res.end(getReport());
            } else if (p === auth + '/view') {
                res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control': 'no-store' });
                res.end(getReport());
            } else {
                res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
                res.end('not found');
            }
        } catch (e) {
            try { res.writeHead(500, { 'Content-Type': 'text/plain' }); res.end('error: ' + e.message); } catch (e2) { /* gone */ }
        }
    }
    share.token = Math.random().toString(36).slice(2, 10);
    const ips = pickIP();
    share.ipAll = ips.all.map((a) => a.name + '=' + a.address);
    if (ips.pick) { share.ip = ips.pick.address; share.iface = ips.pick.name; }
    if (!share.ip) {
        share.status = '车机没联网';
        share.err.push('没有可用的 IPv4 地址,请先让车机连上 Wi-Fi 或开热点');
        return share;
    }
    openServer(handler, PORT_PREF).then((r) => {
        if (!r.port) {
            share.status = '端口打不开';
            share.err.push(r.err || 'listen 失败');
            return;
        }
        share.server = r.server;
        share.port = r.port;
        share.url = 'http://' + share.ip + ':' + share.port + '/t/' + share.token;
        share.status = '服务已开';
        probeNative(share);
        const guard = () => queued(() => ensureRule(share.iface, share.port)).then((fw) => { share.fw = fw; });
        guard();
        share.timer = setInterval(guard, 30000);
        if (share.timer.unref) share.timer.unref();
    });
    return share;
}

function stopShare(share) {
    if (!share) return;
    if (share.timer) { try { clearInterval(share.timer); } catch (e) { /* gone */ } }
    share.timer = null;
    if (share.server) { try { share.server.close(); } catch (e) { /* gone */ } }
    share.server = null;
    share.url = '';
}

/* ---------- the code ---------- */
function qrModules(text) {
    const code = qrcodegen.QrCode.encodeText(text, qrcodegen.QrCode.Ecc.LOW);
    return { size: code.size, dark: (x, y) => code.getModule(x, y) };
}

function drawQr(cv, text, x, y, side, quiet) {
    const m = qrModules(text);
    const n = m.size + quiet * 2;
    const sc = Math.max(1, Math.floor(side / n));
    const real = n * sc;
    cv.fillRect(x, y, real, real, '#ffffff');
    for (let r = 0; r < m.size; r++) {
        for (let c = 0; c < m.size; c++) {
            if (m.dark(c, r)) cv.fillRect(x + (c + quiet) * sc, y + (r + quiet) * sc, sc, sc, '#101010');
        }
    }
    return real;
}

module.exports = { pickIP, htmlPage, startShare, stopShare, ensureRule, qrModules, drawQr, runFallbacks, tryArchiveDir, tryUsb, tarGz };
