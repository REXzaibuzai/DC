#!/usr/bin/env node
'use strict';
/* env-probe-share: root service. Serves the report the env-probe app writes to
 * /tmp/env_probe_scan.txt, and keeps the firewall rule that lets a phone on
 * the car's hotspot reach it. Same shape as the CarPlay maps logs service. */
var fs = require('fs');
var os = require('os');
var http = require('http');
var cp = require('child_process');

var PORT = 8472;
var FILE = '/tmp/env_probe_scan.txt';
var COMMENT = 'env-probe-share';
var IFACE = 'wlan_bridge';
var NFT = null;
var LAST = { host: '', at: 0 };

function findNft() {
    if (NFT) return NFT;
    var dirs = ['/usr/sbin', '/sbin', '/usr/bin', '/bin'];
    for (var i = 0; i < dirs.length; i += 1) {
        try { if (fs.existsSync(dirs[i] + '/nft')) { NFT = dirs[i] + '/nft'; return NFT; } } catch (e) { /* next */ }
    }
    NFT = 'nft';
    return NFT;
}

function nft(args) {
    return new Promise(function (resolve, reject) {
        cp.execFile(findNft(), args, { timeout: 15000, maxBuffer: 4 << 20 }, function (err, out, stderr) {
            if (!err) { resolve(String(out || '')); return; }
            reject(new Error(String(stderr || err.message || '').trim() || 'nft failed'));
        });
    });
}

function ifaceName() {
    var ifs = os.networkInterfaces();
    var names = Object.keys(ifs);
    for (var i = 0; i < names.length; i += 1) {
        if (/^wlan/i.test(names[i]) || /bridge/i.test(names[i])) {
            return names[i];
        }
    }
    return IFACE;
}

function ensureRule() {
    return nft(['-a', 'list', 'chain', 'ip', 'filter', 'input']).then(function (out) {
        var lines = out.split('\n').filter(function (l) { return l.indexOf('comment "' + COMMENT + '"') >= 0; });
        if (lines.length) return true;
        return nft(['insert', 'rule', 'ip', 'filter', 'input', 'iifname', '"' + ifaceName() + '"',
            'tcp', 'dport', String(PORT), 'accept', 'comment', '"' + COMMENT + '"']).then(function () { return true; });
    }).catch(function (e) {
        console.log('rule: ' + (e && e.message));
        return false;
    });
}

function ip() {
    var ifs = os.networkInterfaces();
    var names = Object.keys(ifs);
    var pick = null;
    for (var i = 0; i < names.length; i += 1) {
        var list = ifs[names[i]] || [];
        for (var j = 0; j < list.length; j += 1) {
            var a = list[j];
            if (!a || a.family !== 'IPv4' || a.internal) continue;
            if (/^(192\.168\.|10\.|172\.(1[6-9]|2\d|3[01])\.)/.test(a.address)) {
                if (/^wlan|bridge/i.test(names[i])) return a.address;
                if (!pick) pick = a.address;
            }
        }
    }
    return pick;
}

function sizeText() {
    try {
        var st = fs.statSync(FILE);
        return { ok: true, kb: (st.size / 1024).toFixed(1), when: st.mtime.toISOString().replace('T', ' ').slice(0, 19) };
    } catch (e) { return { ok: false, kb: '0', when: '-' }; }
}

function page() {
    var st = sizeText();
    var host = ip() || '?';
    return '<!doctype html><html lang="zh-CN"><head><meta charset="utf-8">'
        + '<meta name="viewport" content="width=device-width,initial-scale=1"><title>环境模型探测 报告</title>'
        + '<style>*{box-sizing:border-box}body{margin:0;padding:22px;background:#0f1115;color:#e8eaee;'
        + 'font:16px/1.6 -apple-system,"PingFang SC",sans-serif}h1{font-size:20px;margin:0 0 4px}'
        + '.sub{color:#8b93a1;font-size:13px;margin-bottom:18px}.card{background:#171a21;border:1px solid #242936;'
        + 'border-radius:12px;padding:16px;margin-bottom:14px}.row{display:flex;justify-content:space-between;'
        + 'padding:6px 0;font-size:14px;border-bottom:1px solid #212532}.row:last-child{border:0}'
        + '.k{color:#8b93a1}.v{font-family:ui-monospace,Menlo,monospace;font-size:13px}'
        + 'a.b{display:block;text-align:center;padding:14px;border-radius:10px;text-decoration:none;'
        + 'font-weight:600;background:#32e875;color:#08130c;margin-top:6px}'
        + (st.ok ? '' : 'a.b{background:#3a3f4a;color:#8b93a1}') + '</style></head><body>'
        + '<h1>环境模型探测 · 报告</h1><div class="sub">车机生成的只读扫描报告,点下面下载。</div>'
        + '<div class="card"><div class="row"><span class="k">状态</span><span class="v">'
        + (st.ok ? '报告已就绪' : '报告还没生成') + '</span></div>'
        + '<div class="row"><span class="k">大小</span><span class="v">' + st.kb + ' KB</span></div>'
        + '<div class="row"><span class="k">时间</span><span class="v">' + st.when + '</span></div>'
        + '<div class="row"><span class="k">地址</span><span class="v">' + host + ':' + PORT + '</span></div></div>'
        + (st.ok ? '<a class="b" href="/report.txt" download>下载 txt</a>'
            : '<div class="sub">先在车机上打开「环境模型探测」,等它扫描完再来。</div>')
        + '</body></html>';
}

function handler(req, res) {
    var p = String(req.url || '/').split('?')[0];
    if (p === '/' || p === '/index.html') {
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
        res.end(page());
        return;
    }
    if (p === '/report.txt') {
        try {
            var body = fs.readFileSync(FILE);
            res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8',
                'Content-Disposition': 'attachment; filename="env_probe_scan.txt"',
                'Content-Length': body.length });
            res.end(body);
        } catch (e) {
            res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
            res.end('no report yet');
        }
        return;
    }
    res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
    res.end('not found');
}

http.createServer(handler).on('error', function (e) {
    console.log('listen: ' + e.message);
}).listen(PORT, '0.0.0.0', function () {
    var host = ip();
    LAST.host = host; LAST.at = Date.now();
    console.log('serving on ' + host + ':' + PORT);
    ensureRule();
    setInterval(ensureRule, 30000);
});
